#this R script generates multiple simulation data in the working directory folder 

#loading required R packages
library("survival")
library("msm")
library("mvtnorm")
library("splines")
require(stats); require(graphics)

##################general description#########################
#This simulation function generates a simulated medicare claims dataset.
#Parameters associated with distribution of age,gender,race, secondary fracture time, follow up time,
#and survival time are predefined in a list named "par". 
#####################Input of function#####################
#"n",total number of subjects and "par" are the inputs of the function
#age: it follows a truncated normal distribution, with parameter "meanAge" as the mean age, "sdAge" as 
  #the standard deviation, "lb" and "ub" as the lower and upper bounds of the truncated normal distribution.
#gender: "pMale" as the percentage of male subjects, and 1-"pMale" as the percentage of female subjects
#race: "pWhite", "pBlack", "pAsian", and "pHispanic" are the percentage distribution by races. Percentage
  #of the other racial group can be calculated as "pOther"=1-pWhite-pBlack-pAsian-pHispanic
#followup time: censoring time is uniformly distributed between "tFollowup" and 2*"tFollowup", 
  #the range could be modified in the function
###############################################################
#################NEED TO MODIFY################################????????????????????????????????????????/
#both secondary fracture times and survival time are generated based on piecewise exponential models
#secondary fracture: "fxBeta" are parameters for the two-piece exponential model
#fxBeta0,1,...6: coefficients for fracture rates 
  #associated with Intercept,age, genderMale, raceBlack,raceAsian,raceHispanic, raceOther,respectively.
#fxBeta01: intercept of second piece
#fxT: times at which the fracture rate changes, first element should always be 0,in increasing order
#survival time: "survBeta" are parameters for the piecewise exponential model
#"survBeta0,1,...6": coefficients for fracture rates associated with Intercept,age, genderMale, 
  #raceBlack,raceAsian,raceHispanic, raceOther,respectively.
#"survBeta01,02,...,08": intercepts of the second, third,..., ninth pieces
#"survBetafx": change of intercept after the incidence of secondary fracture
#survT: times at which the survival rate changes, each time interval has equal length of 0.5 year
######################Output of funcion##########################
#a (nx9) data frame "data" is the output of the function
#each row indicates a subject
#each column refers to a covariate or outcome
###################Covaraites/Outcomes of data
#age
#gender
#race
#fxTime: time to secondary fracture
#survTime: time to death
#followTime: time to the end of study
#ObsSurvTime: observed survival time
#fx: 1: secondary fracture happened during follow up, 0: no secondary fracture
#death: 1: death happend during follow up, 0: no death

###percentage distributions are calculated based on the data on Medicare Beneficiaries with index fracture in 2009
#n<-1000
#n: total number of subjects

###################################
########covariates#################
###################################
meanAge<-80
#meanAge: mean age
sdAge<-10
#sdAge: standard deviation of age
lb<-66
ub<-100
#upper & lower bounds of truncated normal distribution of age

pMale<-round(1-213980/274525,digits=4)
#pMale: percentage of male subjects
pWhite<-round(256404/274523,digits=4)
pBlack<-round(8542/274523,digits=4)
pAsian<-round(2553/274523,digits=4)
pHispanic<-round(3236/274523,digits=4)
#pWhite, pBlack, pAsian, pHispanic: percentage distribution by races

pTreat<-0.5 #proportion of treatment; 1-pTreat: control

pSSRI<-c(0.5,0.5) # proportion of SSRI usage

####################################
#########survival coeff#############
####################################
survBeta<-rbind(c(0.008334,		0.002617),
                c(0.011061, 	0.003004)

)

survT<-c(0.00,	24.57)

#censoring coeff
tFollowup<-72/2 #max duration_month
#followup time (censoring time is uniformly distributed between tFollowup and 2*tFollowup, the range could be modified in the function)

########################################
#########parameters for cost############
########################################

betac<-c(8.281967,		(0.016210+2))
#intercept, fixed effect

bscoeff<-rbind(c(-3.220151,		0.3703467),
               c(-2.826010,		0.3719807),
               c(-3.155351,		0.4593397),
               c(-1.340526,		0.5783957)
)

sigma<-1.426185/10

upsilon<-2.334002/10


#parameters for piecewise exponential distribution of survival time
par<-list(pAge=c(meanAge,sdAge,lb,ub),pGender=pMale,pRace=c(pWhite,pBlack,pAsian,pHispanic),pTreat=pTreat,pSSRI=pSSRI,SurvBeta=survBeta,SurvT=survT,tFollowup=tFollowup,betac=betac,bscoeff=bscoeff,sigma=sigma,upsilon=upsilon)


######################################
########others########################
######################################
simulation<-function(j=1,n,par,noise=1,bsdegree=2,bsknots=c(9.60,	21.80))
{
  set.seed(j)
  ID<-c(1:n)
  meanAge<-par$pAge[1]
  sdAge<-par$pAge[2]
  lb<-par$pAge[3]
  ub<-par$pAge[4]
  t.norm<-function(n,mean=0,sd=1,lower=-Inf,upper=Inf)
  {
    x<-{}
    repeat
      {
      x<-c(x, rnorm(10*n,mean,sd))
      x<-x[which(x >=lower & x<=upper)]
      if(length(x) >= n)
      {break}
      }
    return(x[1:n])
  }
  age<-t.norm(n,meanAge,sdAge,lb,ub)
  pMale<-par$pGender
  gender<-factor(sample(c(0,1),n,replace=TRUE,prob=c(1-pMale,pMale)),labels=c("Female","Male"))
  ######sampled from the population, not restricted to be exactly the same as the proportions
  pOther<-1-sum(par$pRace)
  race<-factor(sample(c("White","Black","Asian","Hispanic","Other"),n,replace=TRUE,prob=c(par[[3]],pOther)),levels=c("White","Black","Asian","Hispanic","Other"))

  trt<-factor(sample(rep(c(1,0),n/2),n,replace=FALSE))
  trt<-as.numeric(trt)
  trt[trt==2]<-0
  
  SSRI<-factor(sample(c(0,1),n,replace=TRUE,prob=par$pSSRI))
  
  data<-data.frame(ID,age,gender,race,trt,SSRI)
  X<-model.matrix(~SSRI, data = data) 
  
  #calculate hazard rates for each group (by rows)
  surv.rates<-(par$SurvBeta)
  surv.rates[,2]<- surv.rates[,1]+ surv.rates[,2]
  surv.rates<-t(surv.rates)
  
  #generate survival time based on the hazard rates and with an upper bound (10000 months)
  r.survtime<-function(n,covariates="SSRI",rate=surv.rates,t=par$SurvT,upper=10000,data=data)
  {
    x<-vector("list",dim(surv.rates)[1])
    for (i in c(1:dim(surv.rates)[1])) 
    {
      repeat
      {
        n<-table(data[[covariates]])[i]
        x[[i]]<-c(x[[i]],rpexp(10*n,rate=surv.rates[i,],t=par$SurvT))
        x[[i]]<-x[[i]][which(x[[i]]<=upper)]
        if(length(x[[i]])>=n)
        {break}
      }
      print(length(x[[i]]))
      x[[i]]<-x[[i]][1:n]
    }
    return(x)
  }
  
  #survTime is a list of simulated survival times
  survTime<-r.survtime(n,covariates="SSRI",rate=surv.rates,t=par$SurvT,upper=10000,data=data)
  
  #add the simulated survival times to the simulation data (assign survival times by covariate groups)
  data$survTime<-NA
  for (i in 1:length(table(data$SSRI)))
  {
    data$survTime[which(SSRI==names(table(data$SSRI))[i])]<-survTime[[i]]
  }
  
  survTime<-data$survTime
  
  followTime<-tFollowup*(1+runif(n))
  #censored time within tFollowup year
  ObsSurvTime<-pmin(survTime,followTime)
  #observed survival time
  death<-ifelse(survTime<=ObsSurvTime,1,0)
  #death indicatorspline
  data<-data.frame(data,followTime,ObsSurvTime,death)

  ###cost simulation
  fixed<-X%*%par$betac

  dat <- vector("list",n)
  cost<-vector("list",n)
  trunc.cost<-vector("list",n)
  time.from.death<-vector("list",n)
  time.from.enroll<-vector("list",n)
  spline.only <- vector("list",n)
  residuals.only <- vector("list",n)

  costtimes1<-unlist(lapply(data$survTime,function(x){rev(seq((x-floor(x)),x,by=1))})) #all time from death
  basis<-bs(costtimes1,knots=bsknots,degree=bsdegree)
  
  survT<-par$SurvT
  bscoeff<-par$bscoeff
  bscoeff.X<-X%*%t(bscoeff)
  
  for (i in 1:n) 
  {
    sigmab<-par$sigma   
   
    if (is.integer(survTime[i])==TRUE) 
    {
      time.from.enroll[[i]]<-0:(survTime[i]-1)
    }
    if (is.integer(survTime[i])==FALSE) 
    {
      time.from.enroll[[i]]<-0:floor(survTime[i])
    }
    
    time.from.death[[i]]<-survTime[i]-time.from.enroll[[i]]
    
    size<-length(time.from.enroll[[i]])
    
    upsilon<-par$upsilon
    
    CW<-(sigmab^2+upsilon^2)*diag(1,size,size)+sigmab^2  
    ww<-rmvnorm(1,sigma=CW)
    
    newspline<-predict(basis,time.from.death[[i]])
    cost[[i]]<-newspline%*%bscoeff.X[i,]+noise*(fixed[i])+t(noise*ww)
    spline.only[[i]]<-newspline%*%bscoeff.X[i,]
    residuals.only[[i]]<-ww
    
    trunc.cost[[i]]<-cost[[i]]

    if (ObsSurvTime[i]<floor(survTime[i]))
    {
      cost[[i]]<-cost[[i]][1:(floor(ObsSurvTime[i])+1)]
      time.from.enroll[[i]]<-0:(floor(ObsSurvTime[i]))
      time.from.death[[i]]<-ObsSurvTime[i]-time.from.enroll[[i]]
      spline.only[[i]]<-spline.only[[i]][1:(floor(ObsSurvTime[i])+1)]
      residuals.only[[i]]<-residuals.only[[i]][1:(floor(ObsSurvTime[i])+1)]
      trunc.cost[[i]]<-cost[[i]]
      trunc.cost[[i]][length(trunc.cost[[i]])]<-trunc.cost[[i]][length(trunc.cost[[i]])]*(1-(ceiling(ObsSurvTime[i])-ObsSurvTime[i]))
    }
  }

  Obs<-floor(ObsSurvTime)+1 
  data<-data.frame(data,Obs)
  data<-data[rep(seq_len(nrow(data)),time=Obs),]
  data[,"Obs"]<-list(NULL)
  
  data<-data.frame(data,time.from.enroll=unlist(time.from.enroll),
                   time.from.death=unlist(time.from.death),cost=unlist(cost),
                   trunc.cost=unlist(trunc.cost),spline.only=unlist(spline.only),
                   residuals.only=unlist(residuals.only))
  return(data)                                                                                                                                 
}

#generate 1000 simulation datasets
export.sim<-function(nsim)
{
  for (k in 1:nsim)
  {
    simdata<-simulation(j=k,n=1000,par=par,noise=1,bsdegree=2,bsknots=c(9.60,	21.80))
    rownames(simdata)<-NULL
    
    file.loc<-paste("~/simdata",k,".csv",sep="")
    write.csv(simdata, file=file.loc)
  }
}

export.sim(1000)

proc.time()
