## this script reads in a simulation dataset and fit both the full likelihood terminal trend model and the simpified model to get parameter estimates

#load R packages
library("msm")
library("splines")
library("stats4")
library("survival")

################################################################
#when running on a linux cluster, uncomment the following code
################################################################
# #use the following command on cluster:
# #Rscript TerminalTrendModel.R $ind
# #where $ind indicates the number of the simulation data set
# data.ind <- commandArgs(trailingOnly = TRUE)
# print(paste("Simulation",data.ind,sep=""))
# #read in simulation dataset
# data.loc<- paste("~/simdata",data.ind,".csv",sep="")
# data1<- read.csv(data.loc,header = TRUE)

################################################################
#use the following code to read in sample simulation data set 
#in the working directory
#comment the following line when running the script on a linux cluster
################################################################
data1<-read.csv("~/simdata1.csv",header=TRUE)

#reformat data1
data1<-data1[,-1]
data1<-data1[with(data1,order(ID)),]
rownames(data1)<-NULL
colnames(data1)[which(names(data1) == "time.from.enroll")] <- "tij"
colnames(data1)[which(names(data1) == "time.from.death")] <- "tijb"
colnames(data1)[which(names(data1) == "trunc.cost")] <- "COST"
colnames(data1)[which(names(data1) == "ObsSurvTime")] <- "duration_month"
data1$nocost<-rep(0,nrow(data1))
data6<-data1
#create a data frame of unique IDs and counts
freq<-data.frame(table(data6$ID)) 
#unique IDs
ID<-unique(data6$ID)
#n: number of unique IDs
n<-dim(freq)[1]

#create a function cov.matrix that creates a matrix of covariates based on the name of covariates and data
#covariates: name(s) of one or more covariates that will be used to build the covariate matrix 
#data: a data frame

cov.matrix<-function(covariates,data)
{
  X<-eval(parse(text=paste("model.matrix(~", covariates, ",data=data)", sep="")))
  return(X)
}

data6$SSRI<-as.factor(data6$SSRI)
#covariate matrix for survival
surv.X<-cov.matrix("SSRI",data6)
#covariate matrix for cost
cost.X<-cov.matrix("SSRI",data6)
#covariate matrix for bspline
bs.X<-cov.matrix("SSRI",data6)

####################################  
#####create group indicators########
####################################
#to create index vectors for subjects in the four groups (to compute their likelihood contributions separately later)

#ID numbers and index for group 1 (ID.GP1:ID numbers for subjects in group 1; ind.Gp1: index numbers for those subjects)
ID.Gp1<-unique(data6$ID[which((data6$death==1)&(data6$nocost==0))])
ind.Gp1<-match(ID.Gp1,ID)
#ID numbers and index for group 2
ID.Gp2<-unique(data6$ID[which((data6$death==1)&(data6$nocost==1))])
ind.Gp2<-match(ID.Gp2,ID)
#ID numbers and index for group 3
ID.Gp3<-unique(data6$ID[which((data6$death==0)&(data6$nocost==0))])
ind.Gp3<-match(ID.Gp3,ID)
#ID numbers and index for group 4
ID.Gp4<-unique(data6$ID[which((data6$death==0)&(data6$nocost==1))])
ind.Gp4<-match(ID.Gp4,ID)

#check
length(ind.Gp1)+length(ind.Gp2)+length(ind.Gp3)+length(ind.Gp4)==n

####################################  
######use the simplified model######
######to create initial values######
###for the full likelihood model####
####################################

##############################
##########survival############
##############################
survTT<-c(0.00,	24.57) #assume the breakpoints are known
#survTT<-0 #if the breakpoints are unknown

#reshape the data from long to wide (only one row for each subject, repeated measurement in separate columns)
data7<-reshape(data6,
               idvar = "ID",
               v.names = c("tij","tijb"),
               timevar = "tij",
               direction = "wide")

###need to modify survreg() function and rate[,i] calculation if covariate changes
surv.initial<-function(data=data7,ID="ID",duration_time="duration_month",censor="death",t=survTT)
{
  library("survival")
  followup<-data[[duration_time]]
  status<-data[[censor]]

  freq<-data.frame(table(data[[ID]])) 
  #unique IDs
  ID<-unique(data[[ID]])
  #n: number of unique IDs
  n<-dim(freq)[1]
  
  ###hazard rates for piecewise survival
  #deciding # of pieces
  if (sum(t)==0)
  {
    numPieces<-ifelse(length(ID)/3>10,3,floor(length(ID)/3))
    #at least 10 subjects in each piece, maximum # of pieces is 9
    survTT<-unname(quantile(data[[duration_time]],probs=seq(0,1,length.out=numPieces+1)))
    survTT[1]<-0
    survTT<-survTT[-length(survTT)]
  } 
  if (sum(t)!=0)
  {
    survTT<-t
    numPieces<-length(survTT)
  }
  
  ######################################################
  
  sim.split<-survSplit(Surv(followup,status) ~.,data=data,cut=survTT[-1])
  sim.split$expo <- sim.split$followup- sim.split$tstart
  
  rate<-matrix(NA,numPieces,length(levels(data$SSRI)))
  s.e.<-matrix(NA,numPieces,length(levels(data$SSRI)))
  surv.lb<-matrix(NA,numPieces,length(levels(data$SSRI)))
  surv.ub<-matrix(NA,numPieces,length(levels(data$SSRI)))
  
  for (i in 1:length(survTT))
  {
    data.surv.tmp<-sim.split[sim.split$tstart==survTT[i],]
    p<-survreg(Surv(expo,status)~SSRI,data=data.surv.tmp,dist="exponential")
    rate[i,]<-exp((-1)*c(coef(p)[1],(coef(p)[1]+coef(p)[-1]))) # this allows for flexible number of levels for the covariates
    s.e.[i,]<-exp((-1)*summary(p)$table[,2])
    tmp.ub<-(summary(p)$table[,1]-1.96*summary(p)$table[,2])
    surv.ub[i,]<-exp((-1)*c(tmp.ub[1],(tmp.ub[1]+tmp.ub[-1])))
    tmp.lb<-(summary(p)$table[,1]+1.96*summary(p)$table[,2])
    surv.lb[i,]<-exp((-1)*c(tmp.lb[1],(tmp.lb[1]+tmp.lb[-1])))
  }
  
  inc.rate=rate
  if (ncol(rate)>1)
  {
    for (i in 2:(ncol(rate)))
    {
      inc.rate[,i]=rate[,i]-rate[,1]
    }
  }
  
  surv.out<-list(survTT=survTT,rate=rate,inc.rate=inc.rate,s.e.=s.e.,surv.lb=surv.lb,surv.ub=surv.ub)
  return(surv.out) #rate is a matrix of piecewise hazard rates
}

surv.par<-surv.initial(data=data7,ID="ID",duration_time="duration_month",censor="death",t=survTT)
survTT<-surv.par$survTT
betaB<-surv.par$inc.rate
betaB.se<-surv.par$s.e.
surv.lb<-surv.par$surv.lb
surv.ub<-surv.par$surv.ub

################################
##########terminal trend########
################################
spline.knots<-c(9.60) #if knots are known
#spline.knots<-0 #if knots are unknown

data6.death<-data6[data6$death==1,]

cost.initial<-function(data=data6.death,knots=spline.knots,ran.ef=1)
{
  library("splines")
  library("lme4")
  spline.df<-2
  spline.degree<-1
  
  if (sum(spline.knots)==0)
  {
    basis1<-bs(data$tijb,df=spline.df,degree=spline.degree,intercept=FALSE)
    spline.knots<-attr(basis1,"knots")
  }
  
  if (sum(spline.knots)!=0)
  {
    spline.knots<-knots
  }
  
  basis.all<-bs(data$tijb,knot=spline.knots,degree=spline.degree,intercept=FALSE)
  
  if (ran.ef==1)
  {
    spl1 <- lmer(COST~basis.all+SSRI+basis.all*SSRI+(1|ID),data=data)
    sigma<-as.numeric(attr(summary(spl1)$varcor$ID,"stddev"))
    upsilon<-as.numeric(attr(summary(spl1)$varcor,"sc"))
    #summary(spl1)
    
    #to get s.e. of random effects 
    dd.ML <- lme4:::devfun2(spl1,useSc=TRUE,signames=FALSE)
    vv <- as.data.frame(VarCorr(spl1))
    pars <- vv[,"sdcor"]
    library("numDeriv")
    hh1 <- hessian(dd.ML,pars)
    vv2 <- 2*solve(hh1)  ## 2* converts from log-likelihood to deviance scale
    ranef.se<-sqrt(diag(vv2))
    sigma.se<-ranef.se[1]  ## get standard errors
    upsilon.se<-ranef.se[2]
  }
  if (ran.ef==0)
  {
    spl1 <- lm(COST~basis.all+SSRI+basis.all*SSRI,data=data)
    sigma<-NA
    upsilon<-NA
    sigma.se<-NA
    upsilon.se<-NA
  }

  #to get fixed effects
  fixed.effects<-as.numeric(summary(spl1)$coefficients[,1])
  all.s.e.<-as.numeric(summary(spl1)$coefficient[,2])
  #actual values of fixed effect for each level
  betaTt<-{}
  betaTt[1]<-fixed.effects[1]
  betaTt[2]<-fixed.effects[1]+fixed.effects[1+spline.df+1]
  
  #incremental values
  betaTt.inc<-{}
  betaTt.inc[1]<-fixed.effects[1]
  betaTt.inc[2]<-fixed.effects[1+spline.df+1]
  betaTt.se<-{}
  betaTt.se[1]<-all.s.e.[1]
  betaTt.se[2]<-all.s.e.[1+spline.df+1]
  
  ksi<-matrix(NA,spline.df,2)
  ksi[,1]<-fixed.effects[c(2:(1+spline.df))]
  ksi[,2]<-fixed.effects[c(2:(1+spline.df))]+fixed.effects[c((spline.df+3):(2*spline.df+2))]
  
  #incremental values
  ksi.inc<-matrix(NA,spline.df,2)
  ksi.inc[,1]<-fixed.effects[c(2:(1+spline.df))]
  ksi.inc[,2]<-fixed.effects[c((spline.df+3):(2*spline.df+2))]
  ksi.se<-matrix(NA,spline.df,2)
  ksi.se[,1]<-all.s.e.[c(2:(1+spline.df))]
  ksi.se[,2]<-all.s.e.[c((spline.df+3):(2*spline.df+2))]
  
  cost.par<-list(spline.degree=spline.degree,spline.knots=spline.knots,betaTt=betaTt,betaTt.inc=betaTt.inc,ksi=ksi,ksi.inc=ksi.inc,sigma=sigma,upsilon=upsilon,betaTt.se=betaTt.se,ksi.se=ksi.se,sigma.se=sigma.se,upsilon.se=upsilon.se)
  return(cost.par)
}

cost.par<-cost.initial(data=data6.death,knots=spline.knots,ran.ef=1)
betaTt<-cost.par$betaTt.inc
ksi<-cost.par$ksi.inc
sigma<-cost.par$sigma
upsilon<-cost.par$upsilon
betaTt.se<-cost.par$betaTt.se
ksi.se<-cost.par$ksi.se
sigma.se<-cost.par$sigma.se
upsilon.se<-cost.par$upsilon.se


########################################  
###combine parameters into one vector###
########################################
#the "skeleton" of parameters
skl.par1 <- list(betaB=betaB,sigma=sigma,upsilon=upsilon,betaTt=betaTt,ksi=ksi)
#the argument for optim() function
par1 <- as.relistable(skl.par1) 
par1 <- unlist(par1)

par1.se <- list(betaB.se=betaB.se,sigma.se=sigma.se,upsilon.se=upsilon.se,betaTt.se=betaTt.se,ksi.se=ksi.se)
par1.se<-as.relistable(par1.se)
par1.se<-unlist(par1.se)




################################################ 
############the full likelihood model###########
################################################
#-Inf likelihood contributions in group 3 are replaced by the lowest likelihood constribution of all subjects

#this function computes the log likelihood contributions of subjects in four groups
tdloglik_gp3.rev2<-function(pars=par1)
{
  #count start time
  ptm1<-proc.time()
  
  #retrieve each parameter from the vector pars
  pars<-relist(pars,skl.par1)
  #note that even pars is created by the as.relistable() command and "skeleton" is stored as an attribute inside "flesh", we still need to specify the "skeleton" attribute here
  #the "skeleton" attribute won't be automatically set because optim() is creating a new vector to pass to pars and not its par argument
  betaB<-pars$betaB
  sigma<-pars$sigma
  upsilon<-pars$upsilon
  betaTt<-pars$betaTt
  ksi<-pars$ksi
  
  print(pars)
  
  #create a basis for bspline using all time to death/end of follow up data
  #the location of knot is manually set to fit the joint modeling program
  basis<-bs(data6$tijb,knots=c(9.60),degree=1,intercept=FALSE)
  ID<-unique(data6$ID)
  n<-length(ID)
  
  ##################################  
  ####matrices of coefficients######
  ##################################
  
  surv.rates<-surv.X%*%t(betaB)
  #surv.rates: each row includes the piecewise hazard rates for all pieces for one subject
  surv.rates<-cbind(data6$ID,surv.rates)
  colnames(surv.rates)<-c("ID",paste("rate",c(1:length(survTT)),by=""))
  #keep 1 row of piecewise hazard rates for each ID 
  surv.rates<-unique(surv.rates)
  
  #create a matrix of fixed cost for all subjects
  cost.fixed<-cost.X%*%betaTt
  cost.fixed<-cbind(data6$ID,cost.fixed)
  cost.fixed<-unique(cost.fixed)
  
  ksi.X<-bs.X%*%t(ksi)
  #ksi.X: each row includes two parameters for the two pieces of bspline for one subject
  ksi.X<-cbind(data6$ID,ksi.X)
  ksi.X<-unique(ksi.X)
  
  #tmp1: a temporary vector that saves log likelihood value for each subject
  tmp1 <- rep(NA,n)
  
  for (i in 1:n) 
  {
    
    ##################################
    ############Group 1###############
    ##################################
    #Likelihood for subjects who died in the study (not censored) and had at least one mea-surement of cost
    if (i %in% ind.Gp1)
    {
      #data: all data for subject i in group 1
      data<-data6[data6$ID==ID.Gp1[match(i,ind.Gp1)],]
      #Yi: all QOL for subject i
      Yi<-data$COST
      #tij: all time from enrollment for subject i
      
      tij<-data$tij
      #tijb: all time from death/end of follow up for subject i
      tijb<-data$tijb
      #ni: number of observations for subject i
      ni<-dim(data)[1]
      #Ji: a nixni matrix of 1
      Ji<-matrix(1,ni,ni)
      #Zij: calculate the predicted basis for bspline by fitting subject i's time to death data
      Zij<-predict(basis,tijb)
      Ri <- diag (1, ni,ni)
      
      ######################################################################
      #the outcome Yi follows a multivariate normal distribution N(miui,Vi)#
      ######################################################################
      #miui: fixed cost + bspline for subject i, -1 is to delete the ID number
      #cost.fixed[cost.fixed[,1]==i,][-1]: fixed cost for subject i
      #Zij%*%ksi.X[ksi.X[,1]==i,][-1]: bspline prediction times the vector of ksi parameter for subject i
      miui<-cost.fixed[i,][-1]+Zij%*%ksi.X[i,][-1]
      Vi<-sigma^2*Ji+upsilon^2*Ri
      
      #log likelihood for subject i
      tmp1[i] <- -0.5*(ni*log(2*pi)+determinant(Vi,logarithm=TRUE)$modulus[1]+t(Yi-miui)%*%solve(Vi)%*%(Yi-miui)-2*log(dpexp(data$duration_month[1],surv.rates[i,][-1],survTT)))
    }
    
    
    ##################################
    ############Group 2###############
    ##################################
    #Likelihood for subjects who died in the study (not censored) but had no measurement of cost
    
    else if (i %in% ind.Gp2) # group 2
    {
      #data: all data for subject ii in group 2
      data<-data6[data6$ID==ID.Gp2[match(i,ind.Gp2)],]
      
      #log likelihood for subject i
      tmp1[i]<-log(dpexp(data$duration_month[1],surv.rates[i,][-1],survTT))
    }
    
    ##################################
    ############Group 3###############
    ##################################
    #Likelihood for subjects who did not die in the study (censored) and had at least one measurement of cost
    
    else if (i %in% ind.Gp3) # group 3
    {
      #data: all data for subject i in group 3
      data<-data6[data6$ID==ID.Gp3[match(i,ind.Gp3)],]
      #Yi: all QOL for subject i
      Yi<-data$COST
      #tij: all time from enrollment for subject i
      tij<-data$tij
      #tijb: all time from death/end of follow up for subject i
      tijb<-data$tijb
      #ni: number of observations for subject i
      ni<-dim(data)[1]
      #Ji: a nixni matrix of 1
      Ji<-matrix(1,ni,ni)
      Ri <- diag (1, ni,ni)
      
      ######################################################################
      #the outcome Yi follows a multivariate normal distribution N(miui,Vi)#
      ######################################################################
      Vi<-sigma^2*Ji+upsilon^2*Ri
      
      #function f3 calculates the log likelihood for subject i given the death time D
      #argument:
      #D: death time
      f3<-function(D)
      {
        #for each element (observedTime) in vector D, apply it to the following function
        #unlist since the output of lapply() is a list
        result <- unlist(lapply(D, function(observedTime)
        {
          #calculate the predicted basis for bspline by fitting subject i's time to death data
          #observedTime-tij: death time-time from enrollment=time to death
          Zsij<-predict(basis,observedTime-tij)
          #miui: fixed cost + bspline for subject i, -1 is to delete the ID number
          #cost.fixed[i,][-1]: fixed cost for subject i
          #Zij%*%ksi.X[i,][-1]: bspline prediction times the vector of ksi parameter for subject i
          miui<-cost.fixed[i,][-1]+Zsij%*%ksi.X[i,][-1]
          #log likelihood contribution for subject i
          
          tmp5 <- (2*pi)^(-ni/2)%*%(sqrt(det((solve(Vi)))))%*%exp(-0.5*t(Yi-miui)%*%solve(Vi)%*%(Yi-miui))*dpexp(observedTime,surv.rates[i,][-1],survTT)
          return(tmp5)
        }))
        
        result<-as.numeric(result)
        return(result)
      }
      
      #integration of function f3 of variable D
      #lower limit: subject i's full follow up time
      #upper limit: 10 years (120 months)
      tmp1[i]<-log(integrate(f3,lower=data$duration_month[1],upper=120)$value)
    }
    
    ##################################
    ############Group 4###############
    ##################################
    #Likelihood for subjects who did not die in the study (censored) but had no measurement of cost
    
    else if (i %in% ind.Gp4) # group 4
    {
      #data: all data for subject i in group 4
      data<-data6[data6$ID==ID.Gp4[match(i,ind.Gp4)],]
      #log likelihood contribution for subject i
      tmp1[i]<-log(1-ppexp(data$duration_month[1],surv.rates[i,][-1],survTT))
    }
    
  }
  
  #replace -Inf by the minimum log likelihood value of all subjects
  tmp1[tmp1==-Inf]<-10000
  tmp1[tmp1==10000]<-min(tmp1)
  
  tmp1<-unlist(tmp1)

  ll1<-sum(tmp1[ind.Gp1])
  ll2<-sum(tmp1[ind.Gp2])
  ll3<-sum(tmp1[ind.Gp3])
  ll4<-sum(tmp1[ind.Gp4])
  #negative log likelihood is used here since the optimization will minimizes the function
  
  #optional: print log likelihood values and running time for each iteration of the optimization process
  # print(paste(c("ll1","ll2","ll3","ll4"),c(ll1,ll2,ll3,ll4),sep="="))
  # print(paste("log.like",-(ll1+ll2+ll3+ll4),sep="="))
  # ptm11<-proc.time()-ptm1
  # time.count<<-c(time.count,unname(ptm11[3]))
  # print(paste("time count",unname(ptm11[3]),sep="="))
  # print("##############NEXT#####################")
  return(-(ll1+ll2+ll3+ll4))
}


############################################  
#########setting up the constraints#########
############################################

#constr.rage is the parameter that is used to set up the range of constraints (+-constr.range*initial value=constraint for most parameters(except for some >0 constraints))
constraints<-function(par=par1,skl.par=skl.par1,constr.range=10)
{
  n<-length(par)
  par.list<-relist(par,skl.par)
  
  positive<-10^(-10)

  
  betaB.dim<-dim(par.list$betaB)
  ksi.dim<-dim(par.list$ksi)
  betaTt.dim<-dim(par.list$betaTt)
  
  #(1:betaB.dim[1]*(betaB.dim[2]-1)) are the additional rows for constraints for the sums of incremental hazard rates
  #if betaB.dim[2]=1, then there are 0 additional rows, dimension of ui becomes 2n x n
  ui<-matrix(0,2*(betaB.dim[1]*(betaB.dim[2]-1)+n),n)
  A<-diag(n)
  B<--diag(n)
  
  #lower and upper bound for the sums of incremental hazard rates in matrix form
  if (betaB.dim[2]>1)
  {
    for (i in c(1:betaB.dim[1]))
    {
      for (j in c(1:(betaB.dim[2]-1)))
      {
        ui[((j-1)*betaB.dim[1]*2+2*(i-1)+1),i] <-1 
        ui[((j-1)*betaB.dim[1]*2+2*(i-1)+1),(i+j*betaB.dim[1])] <-1 #i.e. betaB1+betaB10>=positive
        ui[((j-1)*betaB.dim[1]*2+2*(i-1)+2),i] <- -1
        ui[((j-1)*betaB.dim[1]*2+2*(i-1)+2),(i+j*betaB.dim[1])] <- -1 #i.e. betaB1+betaB10<=constr.range * abs(betaB1+betaB10)
      }
    }
  }
  
  #lower bound and upper bound for single parameters in matrix form
  ui[seq(2*(betaB.dim[1]*(betaB.dim[2]-1))+1,2*(betaB.dim[1]*(betaB.dim[2]-1)+n),2),] <- A #lower constraints
  ui[seq(2*(betaB.dim[1]*(betaB.dim[2]-1))+2,2*(betaB.dim[1]*(betaB.dim[2]-1)+n),2),] <- B #upper constraints
  
  #lower bound values for sums
  lb.ci1<-rep(positive,betaB.dim[1]*(betaB.dim[2]-1))
  #lower bound values for single parameters
  lb.ci2<-c(rep(positive,betaB.dim[1]),-constr.range*abs(as.vector(par.list$betaB)[c((betaB.dim[1]+1):(betaB.dim[1]*betaB.dim[2]))]),rep(positive,2),-constr.range*abs(par.list$betaTt),-constr.range*abs(as.vector(par.list$ksi)))
  #combined lower bound values
  lb.ci<-  c(lb.ci1,lb.ci2)
  
  #upper bound values for sums
  ub.ci1<-{}
  if (betaB.dim[2]>1)
    {
      for (i in c(2:betaB.dim[2]))
      {
        ub.ci1<-cbind(ub.ci1,par.list$betaB[,1]+par.list$betaB[,i])
      }
    }  
  ub.ci1<-constr.range*abs(as.vector(ub.ci1))
  #upper bound values for single parameters
  ub.ci2<- unlist(lapply(par.list,function(x){constr.range*abs(as.vector(x))}))
  #combined upper bound values
  ub.ci<-c(ub.ci1,ub.ci2)

  ci<-rep(NA,1)
  ci[seq(1,2*(betaB.dim[1]*(betaB.dim[2]-1)+n)-1,2)] <- lb.ci
  ci[seq(2,2*(betaB.dim[1]*(betaB.dim[2]-1)+n),2)] <- -ub.ci
  
  return(list(ui=ui,ci=ci))
}


library("rootSolve")
gradR_gp3.rev<-function(x)
{
  return (gradientR<-gradient(f=tdloglik_gp3.rev2,x=x))
}

ui_ci<-constraints(par=par1,skl=skl.par1,constr.range=10)
ui<-ui_ci$ui
ci<-ui_ci$ci

consoptim.obj1<-constrOptim(theta=par1,f=tdloglik_gp3.rev2,grad=gradR_gp3.rev,ui=ui,ci=ci,method ="BFGS", hessian=TRUE)
V1<-solve(consoptim.obj1$hessian)
std1<-(data.frame(sqrt(diag(V1))))
para1<-(consoptim.obj1$par)
estimate1<-cbind(para1,std1)
names(estimate1)<-c("Estimate","SE")

file.loc1<- paste("~/Estimate/Estimate",data.ind,".csv",sep="")
file.loc2<- paste("~/Hessian",data.ind,".csv",sep="")
file.loc3<- paste("~/Covariance",data.ind,".csv",sep="")
file.loc4<- paste("~/Optim.out",data.ind,".csv",sep="")
file.loc5<- paste("~/Initial.Values",data.ind,".csv",sep="")
file.loc6<- paste("~/Surv.CI",data.ind,".csv",sep="")

write.csv(estimate1, file=file.loc1)
write.csv(consoptim.obj1$hessian, file=file.loc2)
write.csv(V1,file=file.loc3)
write.csv(data.frame(par1,par1.se),file=file.loc5)
write.csv(data.frame(lb=as.vector(surv.lb),ub=as.vector(surv.ub)),file=file.loc6)

out_file <- file(file.loc4 , open="a")  #creates a file in append mode
for (i in seq_along(consoptim.obj1)){
  write.table(names(consoptim.obj1)[i], file=out_file, sep=",", dec=".", 
              quote=FALSE, col.names=FALSE, row.names=FALSE)  #writes the name of the list elements ("A", "B", etc)
  write.table(consoptim.obj1[[i]], file=out_file, sep=",", dec=".", quote=FALSE, 
              col.names=NA, row.names=TRUE)  #writes the data.frames
}
close(out_file)

proc.time()


