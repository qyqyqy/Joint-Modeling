General description:
Simulation Setting I folder includes R scripts and a sample simulation data for simulation under setting I (linear splines). Simulation Setting II folder includes R scripts and a sample simulation data for simulation under setting II (quadratic splines). 
In the application section, the Medicare claims data we used in our study involve a Data Use Agreement (DUA) with the Centers for Medicare & Medicaid Services (CMS). We cannot provide the data due to the limited use. Our dataset was built based on data produced under another study (Munson JC, Bynum JPW, Bell J, et al. Patterns of Prescription Drug Use Before and After Fragility Fracture. JAMA Intern Med. 2016;176(10):1531–1538. doi:https://doi.org/10.1001/jamainternmed.2016.4814). Further inclusion and exclusion criteria for our dataset can be found in the application section of our paper.

Files in each simulation folder:
Simulation1.R and Simulation2.R scripts generate all the simulation datasets (nsim=1000), each with 1000 subjects for simulation under setting I and setting II respectively.
simdata1.csv and simdata2.csv are two sample simulation data sets for setting I and setting II respectively.
TerminalTrendModel1.R and TerminalTrendModel2.R scripts fit both the full likelihood terminal trend model and the simplified model to the simulation data sets under setting I and setting II respectively. Additional script is required to run multiple simulation simultaneously on a Linux cluster.
